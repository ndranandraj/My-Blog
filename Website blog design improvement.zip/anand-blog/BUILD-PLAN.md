# Anand's Blog — Build Plan & Spec

Single source of truth for taking the mockups in this folder live on
**ndranandraj.com** (Hugo 0.153 + PaperMod).

**Legend:** ✅ done in the mockups (copy the pattern) · 🔨 to build in Hugo · 🟡 optional/polish

Files in this folder:
- `Anand - Homepage.dc.html` — homepage: grouped nav, TN 2026 dropdown, mobile menu, responsive
- `Anand - Blog.dc.html` · `Anand - Data.dc.html` · `Anand - Photography.dc.html` · `Anand - About.dc.html` — section pages, all sharing the same nav + responsive grids
- `NAV-IMPROVEMENTS.md` — detailed nav porting guide (Hugo `menu.main` config, URL table, a11y, dropdown JS)
- `support.js` — runtime for the `.dc.html` mockups (preview only; **not** shipped)

> **Decisions locked in:** section pages (Photography / Data / About) are approved as-is ·
> TN 2026 links are **grouped** under one dropdown · the grouped nav is applied across **all** pages.

---

## Phase 1 — Navigation & links · *high impact, ~half a day*

- ✅ Nav collapsed to **Blog · TN 2026 ▾ · Photography · Data · About** + Search + Subscribe (all pages)
- ✅ **TN 2026 dropdown** (Analysis · Results · Explorer · Dataset)
- ✅ **Mobile hamburger menu** (slide-down, TN 2026 expanded inline) below 880px
- ✅ Active page highlighted as the accent pill in the nav
- ✅ Every nav / hero / card / footer item is a real `<a>` / `<button>`
- 🔨 Port the nav to a PaperMod **header partial override** + `menu.main` config — see `NAV-IMPROVEMENTS.md`
- 🔨 Move **Archive** into the footer (out of the top nav)
- 🔨 Add `:focus-visible` outlines (mockups rely on hover; keyboard users need a visible ring)
- 🔨 Dropdown: open on **hover** (desktop) + **click/Enter** (touch/keyboard), close on outside-click + `Esc`, toggle `aria-expanded`

**Done when:** every link resolves, nav fits on mobile, dropdown is keyboard-operable.

---

## Phase 2 — Filters, search & interactive bits · *medium, ~half a day*

These are styled but inert in the mockups — wire them to real Hugo routes/behaviour.

- 🔨 **Blog category pills** (`All · Tech · Data · Personal · Science · Travel · Photography`) →
  link each to its taxonomy page, e.g. `/categories/tech/`. "All" → `/posts/`.
  Mark the active pill with the accent style (the mockup shows the pattern).
- 🔨 **Photography collection pills** (`All · Wildlife · Birds · Astro · Travel · Street`) →
  link to `/categories/photography/<collection>/` or a tag, whichever you tag photos with.
- 🔨 **"Load older posts"** (Blog) → Hugo pagination (`paginate = 9` in config; use `.Paginator`).
  Replace the static "Showing 7 of 19" with `{{ .Paginator.PageNumber }}` / total counts.
- 🔨 **Search** (nav icon) → wire to your existing `/search/` page (Fuse.js index PaperMod ships).
- 🔨 **Newsletter forms** (homepage + blog) → point the `<form>` at Buttondown
  (`https://buttondown.com/api/emails/embed-subscribe/ndranandraj`), real `<input type="email">`, required.
- 🔨 **Dataset download links** (Data page) → real file URLs (CSV / JSON / Parquet) with correct `download` attrs.

**Done when:** filters navigate to real taxonomy pages, pagination works, search + subscribe submit.

---

## Phase 3 — Responsive & accessibility · *high impact, ~half a day*

- ✅ All grids collapse at 880px / 560px (hero, dashboards, post grid, tools, masonry, topics, footers)
- ✅ Tap targets ≥44px (hamburger, theme, subscribe)
- 🔨 Dropdown dismissible via outside-click + `Esc`; `aria-expanded` on toggles (carry over from Phase 1)
- 🔨 Color-contrast audit in **both** light and dark themes (WCAG AA) — especially muted text on the glass cards
- 🔨 `font-display:swap` on the Google Fonts link to avoid invisible-text flash
- 🔨 `prefers-reduced-motion`: disable the float/drift blob animations for users who opt out

**Done when:** fully usable on a phone and by keyboard, both themes, no motion for opted-out users.

---

## Phase 4 — Content correctness · *quick, ~1 hour*

- 🔨 **Essay count:** hero badge says 18 but topic counts sum to 19 (Data 11 + Tech 4 + Travel 2 + Photography 2).
  Reconcile — ideally render `{{ len (where .Site.RegularPages "Section" "posts") }}` so it's never stale.
- 🔨 Give every post `cover.image` front matter so the card "COVER IMAGE" placeholders fill automatically.
- 🟡 Surface **"TVK 233: A Debut, Mapped"** higher than the footer if it's strong work.
- 🟡 Confirm the per-page hero copy (Blog / Data / Photography / About) matches the live tone.

---

## Phase 5 — SEO & sharing · *medium, ~half a day*

- 🔨 **Per-post OG images** — auto-generate social cards (title over a template) instead of one `og-default.png`.
- 🔨 `Article` / `BlogPosting` **JSON-LD** structured data on posts.
- 🔨 Verify sitemap + RSS are current; confirm canonical tags per page (PaperMod handles most).

---

## Phase 6 — Polish & performance · *ongoing*

- 🟡 Lazy-load below-the-fold images; serve responsive `srcset` sizes.
- 🟡 Audit the animated gradient blobs on low-end mobile (reduce blur radius or count if janky).
- 🟡 Minify/inline critical CSS; defer non-critical JS.
- 🟡 **Lighthouse** pass — target 90+ on Performance, Accessibility, Best Practices, SEO.

---

## Per-page build checklist

**Homepage** — nav ✅ · hero ✅ · dashboards cards → real dashboard URLs 🔨 · writing rows → post URLs 🔨 · topic cards → taxonomy URLs 🔨 · newsletter form 🔨
**Blog** — nav ✅ · category pills 🔨 · featured + post grid → post URLs 🔨 · pagination 🔨 · newsletter form 🔨
**Data** — nav ✅ · featured explorer → dashboard URL 🔨 · tools cards → URLs 🔨 · dataset table → download URLs 🔨
**Photography** — nav ✅ · collection pills 🔨 · gallery tiles → real photos + lightbox 🟡 · gear strip (static, fine) ✅
**About** — nav ✅ · bio/timeline (static, fine) ✅ · "Now" cards → keep updated 🟡 · contact CTA → mailto/contact 🔨

---

## Mockup → live URL map (also in NAV-IMPROVEMENTS.md)

| Mockup link | Live URL |
|---|---|
| Blog | `/posts/` |
| TN 2026 → Analysis | `/tamil-nadu-elections-2026/` |
| TN 2026 → Results | `/tn-2026-results/` |
| TN 2026 → Explorer | `/election-dashboard/tn-2026-explorer.html` |
| TN 2026 → Dataset | `/data/tn-2026-candidates/` |
| Photography | `/categories/photography/` |
| Data | `/data/` |
| About | `/page/about/` |
| Search | `/search/` |
| Subscribe / Newsletter | `https://buttondown.com/ndranandraj` |
| Archive (footer) | `/archives/` |
| RSS | `/index.xml` |

---

## Suggested order of attack
1. **Phase 1** (nav) — most visible win, unblocks navigation.
2. **Phase 2** (filters/search/forms) — makes the site functional, not just navigable.
3. **Phase 3** (responsive/a11y) — required before promoting.
4. **Phase 4** (content) — fast, do alongside 2–3.
5. **Phase 5–6** — incremental, post-launch.
