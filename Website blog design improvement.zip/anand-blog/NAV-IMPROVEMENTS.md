# Navigation improvements — mockup + porting guide

This folder contains an updated **`Anand - Homepage.dc.html`** mockup with a redesigned
navigation. Open it and try: click **TN 2026 ▾** (desktop dropdown), shrink the window
below ~880px (hamburger + slide-down mobile menu), and toggle Light/Dark.

---

## What changed vs the live site

**Before (live):** 8 flat top-level items — Blog · TN 2026 Analysis · TN 2026 Results ·
About · Data · Photography · Archive · Search. Crowded, and election links dominate.

**After (mockup):** 5 items + search + subscribe
- **Blog**
- **TN 2026 ▾** — dropdown grouping the election hub: *Analysis · Results · Explorer · Dataset*
- **Photography**
- **Data**
- **About**
- 🔍 **Search** (icon button) · **Subscribe** (CTA)
- **Archive** moved into the footer (low-frequency link)

Plus:
- A real **mobile hamburger menu** (slide-down panel) under 880px — the desktop nav and CTA hide, everything stacks, the TN 2026 group expands inline.
- All nav, hero, card, topic, and footer items are now real **links** (were dead `<span>`s).
- A keyboard/screen-reader-friendly `<button>` for the dropdown and theme/menu toggles.

> **Note:** In the mockup, every TN 2026 sub-link points at the local `Anand - Data.dc.html`
> page so navigation works offline. Use the real URLs (below) when porting.

---

## Porting to Hugo + PaperMod

Your site is **Hugo 0.153 + PaperMod**. The nav is almost certainly driven by
`hugo.toml`/`config.yml` `menu.main` entries and a custom header partial. Two ways to do this:

### 1. Group the TN 2026 items (data side)
PaperMod's default menu is flat. To get a dropdown you need either a submenu-capable
header partial or a small CSS/JS addition. Define the parent + children in config, e.g.:

```toml
[[menu.main]]
  name = "Blog"
  url = "/posts/"
  weight = 10
[[menu.main]]
  name = "TN 2026"
  url = "/tamil-nadu-elections-2026/"
  weight = 20
  [menu.main.params]
    hasChildren = true
[[menu.main]]
  name = "Analysis"
  parent = "TN 2026"
  url = "/tamil-nadu-elections-2026/"
  weight = 21
[[menu.main]]
  name = "Results"
  parent = "TN 2026"
  url = "/tn-2026-results/"
  weight = 22
[[menu.main]]
  name = "Explorer"
  parent = "TN 2026"
  url = "/election-dashboard/tn-2026-explorer.html"
  weight = 23
[[menu.main]]
  name = "Dataset"
  parent = "TN 2026"
  url = "/data/tn-2026-candidates/"
  weight = 24
# Photography, Data, About as flat items; Archive removed from menu (keep in footer)
```

Stock PaperMod ignores `parent`, so override the header: copy
`themes/PaperMod/layouts/partials/header.html` to `layouts/partials/header.html` and render
children of an item with `hasChildren` inside a `<ul>` that shows on hover/focus/click.

### 2. Real URLs to wire up
| Mockup link | Live URL |
|---|---|
| Blog | `/posts/` |
| TN 2026 → Analysis | `/tamil-nadu-elections-2026/` |
| TN 2026 → Results | `/tn-2026-results/` |
| TN 2026 → Explorer | `/election-dashboard/tn-2026-explorer.html` |
| TN 2026 → Dataset | `/data/tn-2026-candidates/` |
| Photography | `/categories/photography/` |
| Data | `/data/` |
| About | `/page/about/` |
| Search | `/search/` |
| Subscribe | `https://buttondown.com/ndranandraj` |
| Archive (footer) | `/archives/` |

### 3. Dropdown behavior (CSS + tiny JS)
- **Open on hover** (desktop) AND **click/Enter** (touch + keyboard). Use
  `:hover`, `:focus-within`, and an `aria-expanded` toggle on the button.
- Close on outside-click and `Esc`.
- Markup pattern: `<li class="has-submenu"><button aria-expanded="false">TN 2026 ▾</button><ul class="submenu">…</ul></li>`.

### 4. Mobile menu
- Below ~880px: hide the desktop `<ul>`, show a hamburger button that toggles a
  `body.menu-open` class (or `aria-expanded` on the button).
- The slide-down panel lists all items; render the TN 2026 children inline (indented),
  not as a hover dropdown, on touch.
- Ensure the toggle is ≥44×44px (it is in the mockup).

### 5. Accessibility checklist (carry over from the mockup)
- Nav links are `<a>`, toggles are `<button>` with `aria-label`/`aria-expanded`.
- Add a visible `:focus-visible` outline (the live site relies on hover only).
- Dropdown is reachable and dismissible by keyboard.

---

## Unrelated fixes worth doing while you're in here
- **Essay count:** hero badge says **18** but the topic counts sum to **19**
  (Data 11 + Tech 4 + Travel 2 + Photography 2). One post is likely double-categorized —
  reconcile the number, or compute it from `len .Site.RegularPages` so it's always correct.
- **Per-post OG images:** you ship one `og-default.png`. Hugo can auto-generate per-post
  social cards (title over a template) for much better link previews.
- **Cover images:** the featured/article cards still show placeholder fills in the mockup —
  PaperMod will fill these from each post's `cover.image` front matter.
